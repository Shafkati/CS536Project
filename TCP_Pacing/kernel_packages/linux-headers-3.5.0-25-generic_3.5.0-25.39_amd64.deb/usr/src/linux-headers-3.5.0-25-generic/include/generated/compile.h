/* This file is auto generated, version 39 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#39 SMP Sun Mar 10 03:53:33 UTC 2013"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ip-10-254-10-245"
#define LINUX_COMPILER "gcc version 4.7.2 (Ubuntu/Linaro 4.7.2-2ubuntu1) "
