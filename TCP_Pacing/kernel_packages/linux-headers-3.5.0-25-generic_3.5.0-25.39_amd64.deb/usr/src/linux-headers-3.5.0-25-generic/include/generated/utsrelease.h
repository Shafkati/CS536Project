#define UTS_RELEASE "3.5.0-25-generic"
